'use strict';

class LinkedList {

}

module.exports = LinkedList;
