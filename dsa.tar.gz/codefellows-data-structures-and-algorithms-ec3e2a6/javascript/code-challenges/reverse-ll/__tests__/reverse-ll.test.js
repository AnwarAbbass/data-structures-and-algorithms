'use strict';

const reverse = require('../reverse-ll.js');

describe('Reverse', () => {
  it('works', () => {
    expect(reverse()).toBeTruthy();
  })
})
