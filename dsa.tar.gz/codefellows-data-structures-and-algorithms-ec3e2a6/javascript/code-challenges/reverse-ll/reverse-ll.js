'use strict';

// Require the linked list implementation
const LinkedList = require('../../linked-list');


/*
  Accept a linked list
  Reveres it
  Return it
*/
module.exports = function reverse(list) {

  return true;

}
