class LinkedList:
    """
    Put docstring here
    """

    def __init__(self):
        # initialization here
        pass

    def some_method(self):
        # method body here
        pass
