from linked_list.linked_list import LinkedList


def test_import():
    assert LinkedList
