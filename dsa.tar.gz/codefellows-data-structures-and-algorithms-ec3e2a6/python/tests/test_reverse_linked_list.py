from code_challenges.reverse_linked_list import reverse_list


def test_import():
    assert reverse_list
